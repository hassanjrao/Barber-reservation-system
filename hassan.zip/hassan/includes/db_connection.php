<?php    
// define('DBHost', 'localhost');
// define('DBPort', 3306);
// define('DBName', 'barber');
// define('DBUser', 'root');
// define('DBPassword', '');


define('DBHost', 'localhost');
define('DBPort', 3306);
define('DBName', 'olactum8_rao');
define('DBUser', 'olactum8_rao');
define('DBPassword', 'Ne6caLeaqFuc');
